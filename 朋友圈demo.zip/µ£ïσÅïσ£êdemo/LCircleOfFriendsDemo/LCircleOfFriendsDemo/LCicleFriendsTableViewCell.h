//
//  LCicleFriendsTableViewCell.h
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/15.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LCircleFriendsModel.h"
#import "LBrowsePhotoView.h"
#import "LPicContentView.h"


@interface LCicleFriendsTableViewCell : UITableViewCell


@property(nonatomic,strong)UIImageView *lwc_headImageView;

@property(nonatomic,strong)UILabel *lwc_title;

@property(nonatomic,strong)UILabel *lwc_time;

@property(nonatomic,strong)UILabel *lwc_content;

@property(nonatomic,strong)LPicContentView  *lwc_bgView;

@property(nonatomic,strong)UILabel *lwc_distent;

@property(nonatomic,strong)UIImageView  *lwc_zanImageView;
@property(nonatomic,strong)UILabel *lwc_zanNumber;

@property(nonatomic,strong)LCircleFriendsModel *dataModel;





@end

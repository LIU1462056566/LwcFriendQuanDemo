//
//  LWaittingProgressView.h
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/16.
//  Copyright © 2017年 刘文超. All rights reserved.
//


//图片下载进度指示器
#import <UIKit/UIKit.h>

typedef enum {
    LWCWaittingModeLoopDiagram,//环形进度条
    LWCWaittingModePieDiagram//饼形进度条
}LWCWaittingViewMode;



@interface LWaittingProgressView : UIView

@property(nonatomic,assign)CGFloat proGress;

@property(nonatomic,assign)LWCWaittingViewMode  mode;


@end

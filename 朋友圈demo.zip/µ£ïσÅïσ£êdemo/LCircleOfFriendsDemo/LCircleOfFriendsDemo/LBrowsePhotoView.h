//
//  LBrowsePhotoView.h
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/16.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBrowserPrentView.h"

@class LBrowsePhotoView;

@protocol LBrowsePhotoViewDelegate <NSObject>

@required

- (UIImage *)photoBrowser:(LBrowsePhotoView *)browser placeholderImageForIndex:(NSInteger)index;
@optional

- (NSURL *)photoBrowser:(LBrowsePhotoView *)browser highQualityImageURLForIndex:(NSInteger)index;

@end



@interface LBrowsePhotoView : UIView<UIScrollViewDelegate>


@property(nonatomic,weak)id<LBrowsePhotoViewDelegate>delegate;

@property(nonatomic,strong)UILabel *lwc_navTitleLable;//标题
@property(nonatomic,strong)UIButton *lwc_saveButton;//保存按钮

@property(nonatomic,strong)UIScrollView *MyScrollview;
@property (nonatomic, assign) NSInteger imageCount;//图片数量
@property (nonatomic, assign) NSInteger CurrentImageCount;//当前图片所处位置

@property (nonatomic, weak) UIView *sourceImagesContainerView;


-(void)show;

@end

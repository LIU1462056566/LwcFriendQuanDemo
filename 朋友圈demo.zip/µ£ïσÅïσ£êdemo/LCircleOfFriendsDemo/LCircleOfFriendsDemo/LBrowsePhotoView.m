//
//  LBrowsePhotoView.m
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/16.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LBrowsePhotoView.h"

@implementation LBrowsePhotoView
{
        UIActivityIndicatorView *_indicatorView;//保存图片指示器
      BOOL _willDisappear;
     BOOL _hasShowedFistView;
}
-(id)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
//        [self setUI];
        self.backgroundColor=[UIColor blackColor];
    }return self;
}

-(void)didMoveToSuperview
{
    
    
    //创建展示图片的view
    
    [self setPresentScrollview];
    //创建标题的view
    [self setNavTextView];
   
    
    
    
}
-(void)setPresentScrollview
{
    
    _MyScrollview=[[UIScrollView alloc]init];
    _MyScrollview.delegate=self;
    _MyScrollview.showsVerticalScrollIndicator=NO;
    _MyScrollview.showsHorizontalScrollIndicator=NO;
    _MyScrollview.pagingEnabled=YES;
    
    [self addSubview:_MyScrollview];
    
    for (int i=0; i<self.imageCount; i++) {
        LBrowserPrentView *imageView=[[LBrowserPrentView alloc]init];
        imageView.tag=i;
        
        //单机图片-----
        UITapGestureRecognizer *singleTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(signTapClick:)];
        
        //双击------放大图片
        UITapGestureRecognizer *doubleTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doubleTapClic:)];
        
        doubleTap.numberOfTapsRequired=2;
        [self addGestureRecognizer:doubleTap];
        //指定某一个 recognizer，即便自己已经滿足條件了，也不會立刻触发，会等到该指定的 recognizer 确定失败之后才触发
        [singleTap requireGestureRecognizerToFail:doubleTap];
        [imageView addGestureRecognizer:singleTap];
        [imageView addGestureRecognizer:doubleTap];
        [_MyScrollview addSubview:imageView];
     
    }
    
  
    [self setUpImageViewForIndex:self.CurrentImageCount];
    
    
    
    
}
#pragma mark----手势点击方法
-(void)signTapClick:(UITapGestureRecognizer *)signTap
{
    _MyScrollview.hidden=YES;
    _willDisappear=YES;
    
    LBrowserPrentView *currentImageView=(LBrowserPrentView *)signTap.view;
    NSInteger currentIndex=currentImageView.tag;
    //找到点击图片在主 view的位置
    UIView *sourceView=self.sourceImagesContainerView.subviews[currentIndex];
    CGRect targetTemp=[self.sourceImagesContainerView convertRect:sourceView.frame toView:self];
    
    //做个动画
    
    UIImageView *tempView=[[UIImageView alloc]init];
    tempView.contentMode=sourceView.contentMode;
    tempView.clipsToBounds=YES;
    tempView.image=currentImageView.image;
    
    CGFloat h = (self.bounds.size.width / currentImageView.image.size.width) * currentImageView.image.size.height;
    
    if (!currentImageView.image) { // 防止 因imageview的image加载失败 导致 崩溃
        h = self.bounds.size.height;
    }
    
    tempView.bounds=CGRectMake(0, 0, self.bounds.size.width, h);
    tempView.center=self.center;
    
    [self addSubview:tempView];
    
    _lwc_saveButton.hidden=YES;
    
    [UIView animateWithDuration:0.4f animations:^{
        tempView.frame=targetTemp;
        self.backgroundColor=[UIColor clearColor];
        _lwc_navTitleLable.alpha=.1;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}
-(void)doubleTapClic:(UITapGestureRecognizer *)doubelTap
{
    LBrowserPrentView *imageView=(LBrowserPrentView *)doubelTap.view;
    CGFloat scale;
    if (imageView.isScaled) {
        scale = 1.0;
    }else{
         scale = 2.0;
    }
    [imageView doubleTapToZoomWithScale:scale];
    
    
    
}

-(void)setUpImageViewForIndex:(NSInteger)index
{
    
    
    LBrowserPrentView *imageView=self.MyScrollview.subviews[index];
    self.CurrentImageCount=index;
    if (imageView.hasLoadedImage) {
        return;
    }
    if ([self highQualityImageURLForIndex:index]) {
        [imageView setImageWithURL:[self highQualityImageURLForIndex:index] placeholderImage:[self placeholderImageForIndex:index]];
    }else{
         imageView.image = [self placeholderImageForIndex:index];
    }
    imageView.hasLoadedImage=YES;
    
    
    
}
- (NSURL *)highQualityImageURLForIndex:(NSInteger)index
{
    if ([self.delegate respondsToSelector:@selector(photoBrowser:highQualityImageURLForIndex:)]) {
        return [self.delegate photoBrowser:self highQualityImageURLForIndex:index];
    }
    return nil;
}
- (UIImage *)placeholderImageForIndex:(NSInteger)index
{
    if ([self.delegate respondsToSelector:@selector(photoBrowser:placeholderImageForIndex:)]) {
        return [self.delegate photoBrowser:self placeholderImageForIndex:index];
    }
    return nil;
}


-(void)setNavTextView
{
    // 1. 序标
    UILabel *indexLabel = [[UILabel alloc] init];
    indexLabel.bounds = CGRectMake(0, 0, 80, 30);
    indexLabel.textAlignment = NSTextAlignmentCenter;
    indexLabel.textColor = [UIColor whiteColor];
    indexLabel.font = [UIFont boldSystemFontOfSize:20];
    indexLabel.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    indexLabel.layer.cornerRadius = indexLabel.bounds.size.height * 0.5;
    indexLabel.clipsToBounds = YES;
    if (self.imageCount > 1) {
        indexLabel.text = [NSString stringWithFormat:@"1/%ld", (long)self.imageCount];
    }else{
        indexLabel.text =[NSString stringWithFormat:@"1/%@", @"1"];
    }
    _lwc_navTitleLable = indexLabel;
    [self addSubview:indexLabel];
    
    // 2.保存按钮
    UIButton *saveButton = [[UIButton alloc] init];
    [saveButton setTitle:@"保存" forState:UIControlStateNormal];
    [saveButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    saveButton.backgroundColor = [UIColor colorWithRed:0.1f green:0.1f blue:0.1f alpha:0.90f];
    saveButton.layer.cornerRadius = 5;
    saveButton.clipsToBounds = YES;
    [saveButton addTarget:self action:@selector(saveImage) forControlEvents:UIControlEventTouchUpInside];
    _lwc_saveButton = saveButton;
    [self addSubview:saveButton];
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    
   
    CGRect rect=self.bounds;
    rect.size.width+=20;
    _MyScrollview.bounds=rect;
    _MyScrollview.center=self.center;
    
    CGFloat y=0;
    CGFloat w=_MyScrollview.frame.size.width-20;
    CGFloat h=_MyScrollview.frame.size.height;
    
    
    
    //遍历数组设置fram
    [_MyScrollview.subviews enumerateObjectsUsingBlock:^(LBrowserPrentView *obj, NSUInteger idx, BOOL * _Nonnull stop) {
        CGFloat x=10+idx*(20+w);
        obj.frame=CGRectMake(x, y, w, h);
    }];
    
    _MyScrollview.contentSize=CGSizeMake(_MyScrollview.subviews.count*_MyScrollview.frame.size.width, 0);
    _MyScrollview.contentOffset=CGPointMake(self.CurrentImageCount*_MyScrollview.frame.size.width, 0);
    
    if (!_hasShowedFistView) {
        [self showFirstImage];
    }
    
    
    //设置控件位置
    _lwc_navTitleLable.center=CGPointMake(self.bounds.size.width/2, 40);
    _lwc_saveButton.frame=CGRectMake(20, ScreenHeight-100, 60, 40);
    
}
- (void)showFirstImage
{
    UIView *sourceView = self.sourceImagesContainerView.subviews[self.CurrentImageCount];
    CGRect rect = [self.sourceImagesContainerView convertRect:sourceView.frame toView:self];
    
    UIImageView *tempView = [[UIImageView alloc] init];
    tempView.image = [self placeholderImageForIndex:self.CurrentImageCount];
    
    [self addSubview:tempView];
    
    CGRect targetTemp = [_MyScrollview.subviews[self.CurrentImageCount] bounds];
    
    tempView.frame = rect;
    tempView.contentMode = [_MyScrollview.subviews[self.CurrentImageCount] contentMode];
    _MyScrollview.hidden = YES;
    
    
    [UIView animateWithDuration:0.4f animations:^{
        tempView.center = self.center;
        tempView.bounds = (CGRect){CGPointZero, targetTemp.size};
    } completion:^(BOOL finished) {
        _hasShowedFistView = YES;
        [tempView removeFromSuperview];
        _MyScrollview.hidden = NO;
    }];
}


//保存图片按钮方法
-(void)saveImage{
    
    int index=_MyScrollview.contentOffset.x/_MyScrollview.bounds.size.width;
    UIImageView *currentImageView=_MyScrollview.subviews[index];
    UIImageWriteToSavedPhotosAlbum(currentImageView.image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
    
    //保存菊花样式
    UIActivityIndicatorView *indicator=[[UIActivityIndicatorView alloc]init];
    indicator.activityIndicatorViewStyle=UIActivityIndicatorViewStyleGray;
    indicator.center=self.center;
    _indicatorView=indicator;
    
    //放到window上展示
    [[UIApplication sharedApplication].keyWindow addSubview:indicator];
    [indicator startAnimating];
 
}
//保存图片是否成功的回调方法
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
   
    
    UILabel *lable=[[UILabel alloc]init];
    lable.textColor=[UIColor whiteColor];
    lable.backgroundColor=[UIColor colorWithRed:0.1f green:0.1f blue:0.1f alpha:0.90f];
    lable.layer.cornerRadius = 5;
    lable.clipsToBounds = YES;
    lable.bounds = CGRectMake(0, 0, 150, 30);
    lable.center = self.center;
    lable.textAlignment = NSTextAlignmentCenter;
    lable.font = [UIFont boldSystemFontOfSize:17];
    [[UIApplication sharedApplication].keyWindow addSubview:lable];
    [[UIApplication sharedApplication].keyWindow bringSubviewToFront:lable];
    if (error) {
        lable.text = @"保存失败";
    }else{
        lable.text = @"保存成功";
    }
     [_indicatorView removeFromSuperview];
//    做个动画  1秒后移除lable
    [lable performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:1.0];
}
- (void)show
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    self.frame = window.bounds;
    [window addObserver:self forKeyPath:@"frame" options:0 context:nil];
    [window addSubview:self];
    
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(UIView *)object change:(NSDictionary *)change context:(void *)context
{
    if ([keyPath isEqualToString:@"frame"]) {
        self.frame = object.bounds;
        LBrowserPrentView *currentImageView = _MyScrollview.subviews[_CurrentImageCount];
        if ([currentImageView isKindOfClass:[LBrowserPrentView class]]) {
            [currentImageView clear];
        }
    }
}
- (void)dealloc
{
    [[UIApplication sharedApplication].keyWindow removeObserver:self forKeyPath:@"frame"];
}
#pragma mark - scrollview代理方法

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    int index = (scrollView.contentOffset.x + _MyScrollview.bounds.size.width * 0.5) / _MyScrollview.bounds.size.width;
    
    // 有过缩放的图片在拖动一定距离后清除缩放
    CGFloat margin = 150;
    CGFloat x = scrollView.contentOffset.x;
    if ((x - index * self.bounds.size.width) > margin || (x - index * self.bounds.size.width) < - margin) {
        LBrowserPrentView *imageView = _MyScrollview.subviews[index];
        if (imageView.isScaled) {
            [UIView animateWithDuration:0.5 animations:^{
                imageView.transform = CGAffineTransformIdentity;
            } completion:^(BOOL finished) {
                [imageView eliminateScale];
            }];
        }
    }
    
    
    if (!_willDisappear) {
        _lwc_navTitleLable.text = [NSString stringWithFormat:@"%d/%ld", index + 1, (long)self.imageCount];
    }
    [self setUpImageViewForIndex:index];
}



@end

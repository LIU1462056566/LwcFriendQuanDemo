//
//  LCircleFriendsModel.m
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/15.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LCircleFriendsModel.h"
#import "LimagesViewPresentModel.h"
@implementation LCircleFriendsModel

+(NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             @"ID":@"id",
             };
}
+(NSDictionary *)mj_objectClassInArray
{
    return @{
             @"pics":@"LimagesViewPresentModel",
             };
}

@end

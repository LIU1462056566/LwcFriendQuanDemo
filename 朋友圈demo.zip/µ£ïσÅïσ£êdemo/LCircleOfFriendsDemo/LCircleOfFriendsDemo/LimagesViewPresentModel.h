//
//  LimagesModel.h
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/15.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LimagesViewPresentModel : NSObject
//** <#注释#> **//
@property(nonatomic,copy)NSString * picBaseCodeUrl   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * picIndex   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * picName   ;
@end

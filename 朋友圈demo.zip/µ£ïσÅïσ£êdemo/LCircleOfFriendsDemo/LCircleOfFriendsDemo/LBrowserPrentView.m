//
//  LBrowserPrentView.m
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/16.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LBrowserPrentView.h"

@implementation LBrowserPrentView
{
    __weak LWaittingProgressView *_waitingView;
    UIScrollView *_scroll;
    UIImageView *_scrollImageView;
    UIScrollView *_zoomingScroolView;//缩放视图
    UIImageView *_zoomingImageView;
    CGFloat _totalScale;
}

-(id)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        self.userInteractionEnabled=YES;
        self.contentMode=UIViewContentModeScaleAspectFit;
        
        _totalScale=1;
        
        //捏合手势缩放图片
        UIPinchGestureRecognizer *pinch=[[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(zoomImage:)];
        [self addGestureRecognizer:pinch];
        pinch.delegate=self;
     
    }return self;
}
-(void)zoomImage:(UIPinchGestureRecognizer *)tap{
    [self prepareForImageViewScaling];
    CGFloat scale=tap.scale;
    CGFloat temp =_totalScale+(scale -1);
    [self setTotalScale:temp];
    tap.scale=1.0;
    
    
}
-(void)setTotalScale:(CGFloat)totalScale
{
    //缩放范围最小0.5倍 最大2倍
    if ((_totalScale<0.5&&totalScale<_totalScale)||(_totalScale>2.0&&totalScale>_totalScale)) {
        return;
    }
    [self zoomWithScale:totalScale];
}
-(void)zoomWithScale:(CGFloat)scale
{
    _totalScale=scale;
    
    _zoomingImageView.transform=CGAffineTransformMakeScale(scale, scale);
    
    if (scale>1) {
        CGFloat contentW = _zoomingImageView.frame.size.width;
        CGFloat contentH = MAX(_zoomingImageView.frame.size.height, self.frame.size.height);
        _zoomingImageView.center=CGPointMake(contentW/2, contentH/2);
        _zoomingScroolView.contentSize=CGSizeMake(contentW, contentH);
        
        CGPoint offset=_zoomingScroolView.contentOffset;
        offset.x=(contentW-_zoomingScroolView.frame.size.width)*0.5;
        _zoomingScroolView.contentOffset=offset;
        
    }else{
        _zoomingScroolView.contentSize=_zoomingScroolView.frame.size;
        _zoomingScroolView.contentInset=UIEdgeInsetsMake(0, 0, 0, 0);
        _zoomingImageView.center=_zoomingScroolView.center;
        
        
    }
    
    
}
-(void)doubleTapToZoomWithScale:(CGFloat)scale
{
    [self prepareForImageViewScaling];
    
    [UIView animateWithDuration:0.5f animations:^{
        [self zoomWithScale:scale];
    } completion:^(BOOL finished) {
        if (scale==1) {
            [self clear];
        }
    }];
    
    
    
}
- (void)clear
{
    [_zoomingScroolView removeFromSuperview];
    _zoomingScroolView = nil;
    _zoomingImageView = nil;
    
}

// 清除缩放
- (void)eliminateScale
{
    [self clear];
    _totalScale = 1.0;
}
- (void)prepareForImageViewScaling
{
    if (!_zoomingScroolView) {
        _zoomingScroolView=[[UIScrollView alloc]initWithFrame:self.bounds];
        _zoomingScroolView.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:0.95];
        _zoomingScroolView.contentSize=self.bounds.size;
        
        UIImageView *zoomingImageview=[[UIImageView alloc]initWithImage:self.image];
        CGSize imageSize = zoomingImageview.image.size;
        CGFloat imageViewH = self.bounds.size.height;
        if (imageSize.width>0) {
            imageViewH=self.bounds.size.width * (imageSize.height / imageSize.width);
        }
        zoomingImageview.bounds = CGRectMake(0, 0, self.bounds.size.width, imageViewH);
        zoomingImageview.center = _zoomingScroolView.center;
        zoomingImageview.contentMode = UIViewContentModeScaleAspectFit;
         _zoomingImageView= zoomingImageview;
        [_zoomingScroolView addSubview:zoomingImageview];
        [self addSubview:_zoomingScroolView];
    }
}


-(BOOL)isScaled
{
    return 1.0!=_totalScale;
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    
    _waitingView.center=CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
    CGSize imageSize=self.image.size;
   //
    if (self.bounds.size.width*(imageSize.height/imageSize.width)>self.bounds.size.height) {
        //防止重复创建视图
        if (!_scroll) {
            UIScrollView *scroll=[[UIScrollView alloc]init];
            scroll.backgroundColor=[UIColor whiteColor];
            UIImageView *imageView=[[UIImageView alloc]init];
            imageView.image=self.image;
            _scrollImageView=imageView;
            [scroll addSubview:imageView];
            scroll.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:0.95];
            _scroll=scroll;
            [self addSubview:scroll];
            //如果有进度条view 就让进度条的view放倒这些视图的前面
            if (_waitingView) {
                [self bringSubviewToFront:_waitingView];
            }
        }
        
        _scroll.frame=self.bounds;
        CGFloat imageViewH=self.bounds.size.width* (imageSize.height / imageSize.width);
        _scrollImageView.bounds=CGRectMake(0, 0, _scroll.frame.size.width, imageViewH);
        _scrollImageView.center=CGPointMake(_scroll.frame.size.width * 0.5, _scrollImageView.frame.size.height * 0.5);
        _scroll.contentSize=CGSizeMake(0, _scrollImageView.bounds.size.height);
    }else{
        //防止屏幕旋转导致出现问题
        if (_scroll) {
            [_scroll removeFromSuperview];
        }
    }
    
    
}

-(void)setLwc_progress:(CGFloat)lwc_progress
{
    _lwc_progress=lwc_progress;
    
    _waitingView.proGress=lwc_progress;
}

- (void)removeWaitingView
{
    [_waitingView removeFromSuperview];
}

@end

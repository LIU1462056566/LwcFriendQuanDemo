//
//  LPicContentView.h
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/17.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBrowsePhotoView.h"
@interface LPicContentView : UIView<LBrowsePhotoViewDelegate>

@property (nonatomic, strong) NSArray *picPathStringsArray;


@end

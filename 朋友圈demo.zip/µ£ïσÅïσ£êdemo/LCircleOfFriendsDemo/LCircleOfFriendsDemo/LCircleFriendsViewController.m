//
//  LCircleFriendsViewController.m
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/15.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LCircleFriendsViewController.h"
#import "LimagesViewPresentModel.h"
#import "LCircleFriendsModel.h"
#import "LCicleFriendsTableViewCell.h"

#import "LBrowsePhotoView.h"
@interface LCircleFriendsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *myTableView;
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,assign)NSInteger page;
@property(nonatomic,strong)NSMutableArray *heightArray;
@end

@implementation LCircleFriendsViewController
-(NSMutableArray *)heightArray
{
    if (!_heightArray) {
        _heightArray=[[NSMutableArray alloc]init];
        
    }return _heightArray;
}
-(NSMutableArray *)dataArr
{
    if (!_dataArr) {
        _dataArr=[[NSMutableArray alloc]init];
        
    }return _dataArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self loadData];
    
    
    _picPathStringsArray=[[NSMutableArray alloc]init];
    
    __weak typeof(self)weaself=self;
    self.myTableView.mj_header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weaself loadData];
    }];
    self.myTableView.mj_footer=[MJRefreshBackNormalFooter  footerWithRefreshingBlock:^{
        [weaself loadMoreData];
    }];
    
    
    [self.view addSubview:self.myTableView];

    
}

-(UITableView *)myTableView
{
    if (!_myTableView) {
        _myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) style:UITableViewStyleGrouped];
        _myTableView.delegate=self;
        _myTableView.dataSource=self;
        
    }return _myTableView;
}

#pragma mark---delete--tableView
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArr.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
     LCircleFriendsModel *model=self.dataArr[indexPath.row];

        static NSString *cellID=@"cell1";
        LCicleFriendsTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell=[[LCicleFriendsTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        cell.dataModel=model;
       
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;

    

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    LCircleFriendsModel *model=self.dataArr[indexPath.row];
    CGFloat height ;
         height = 90+[self currentSizePingLun:model.dynamicContents].height;;
    return height+[model.ImageHeight floatValue]+20;

}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return .1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return .1;
}


-(CGSize)currentSizePingLun:(NSString *)info
{
    
    CGSize size;
    //获取当前系统的版本号
    float version=[[UIDevice currentDevice].systemVersion floatValue];
    UIFont *font=[UIFont systemFontOfSize:14];
    if(version>=7.0){
        //计算显示文本内容需要的大小
        //第1个参数是大小，主要指定宽度
        //第2个参数是计算大小的参照，主要参照字体和换行样式
        //第3个参数是字典，封装字体
        //第4个参数可选的，一般为nil
        size=[info boundingRectWithSize:CGSizeMake(ScreenWidth-70, 999) options:NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingTruncatesLastVisibleLine attributes:@{NSFontAttributeName:font} context:nil].size;
    }else{
        size=[info sizeWithFont:font constrainedToSize:CGSizeMake(ScreenWidth-70, 999) lineBreakMode:NSLineBreakByCharWrapping];
    }
    return size;
}
-(void)loadData
{
    _page=1;
    NSMutableDictionary *Dict=[[NSMutableDictionary alloc]init];
    [Dict setObject:[NSString stringWithFormat:@"%ld",_page] forKey:@"pageNum"];
    
    __weak typeof(self)weaself=self;
  [[AFHTTPSessionManager manager] GET:@"http://zk-finance2-http-dev.ipaas.zhonglele.com:80/app/sellerDynamicService/getSellerDynamics/1/1?pageNum=1&userId=1" parameters:Dict progress:^(NSProgress * _Nonnull downloadProgress) {
  } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
      
      NSLog(@"数据-----%@",responseObject);
      NSArray *classArr=responseObject[@"datas"];
      [weaself.dataArr removeAllObjects];
      for (NSDictionary *ClassDict in classArr) {
          LCircleFriendsModel *model=[LCircleFriendsModel mj_objectWithKeyValues:ClassDict];
          [LCircleFriendsModel mj_objectClassInArray];
          [weaself.dataArr addObject:model];
      }

      
      if (classArr.count<10) {
          [weaself.myTableView.mj_footer endRefreshingWithNoMoreData];
      }else{
          [weaself.myTableView.mj_footer endRefreshing];
      }
      
      
      
      
      
      [weaself.myTableView reloadData];
      
      [weaself.myTableView.mj_header endRefreshing];
      
  } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
      NSLog(@"----请求失败%@",error);
  }];
    
    
    
}
-(void)loadMoreData
{
    _page=_page+1;
    NSMutableDictionary *Dict=[[NSMutableDictionary alloc]init];
    [Dict setObject:[NSString stringWithFormat:@"%ld",_page] forKey:@"pageNum"];
    __weak typeof(self)weaself=self;
    [[AFHTTPSessionManager manager] GET:@"http://zk-finance2-http-dev.ipaas.zhonglele.com:80/app/sellerDynamicService/getSellerDynamics/1/1?pageNum=1&userId=1" parameters:Dict progress:^(NSProgress * _Nonnull downloadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"数据-----%@",responseObject);
        NSArray *classArr=responseObject[@"datas"];
        
        for (NSDictionary *ClassDict in classArr) {
            LCircleFriendsModel *model=[LCircleFriendsModel mj_objectWithKeyValues:ClassDict];
            [LCircleFriendsModel mj_objectClassInArray];
            
            [weaself.dataArr addObject:model];
        }
        
        if (classArr.count<10) {
            [weaself.myTableView.mj_footer endRefreshingWithNoMoreData];
        }else{
            [weaself.myTableView.mj_footer endRefreshing];
        }
        
        
        
        [weaself.myTableView reloadData];
        
        [weaself.myTableView.mj_header endRefreshing];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"----请求失败%@",error);
    }];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

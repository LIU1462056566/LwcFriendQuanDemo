//
//  LPicContentView.m
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/17.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LPicContentView.h"

@interface LPicContentView ()
@property (nonatomic, strong) NSArray *imageViewsArray;
@end


@implementation LPicContentView

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
    
        [self setUP];
    }return self;
}
-(void)setUP{
    
    NSMutableArray *temp = [NSMutableArray new];
    
    for (int i = 0; i < 9; i++) {
        UIImageView *imageView = [UIImageView new];
        [self addSubview:imageView];
        imageView.contentMode=UIViewContentModeScaleAspectFit;
        imageView.userInteractionEnabled = YES;
        imageView.tag = i;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapImageView:)];
        [imageView addGestureRecognizer:tap];
        [temp addObject:imageView];
    }
    
    self.imageViewsArray = [temp copy];
    
    
}
- (void)tapImageView:(UITapGestureRecognizer *)tap
{
        UIView *imageView = tap.view;
        LBrowsePhotoView *browser = [[LBrowsePhotoView alloc] init];
        browser.CurrentImageCount=imageView.tag;
        browser.sourceImagesContainerView=self;
        browser.delegate=self;
        browser.imageCount=self.picPathStringsArray.count;
    
        [browser show];
}
#pragma mark----browersdelegate
- (UIImage *)photoBrowser:(LBrowsePhotoView *)browser placeholderImageForIndex:(NSInteger)index
{
        UIImageView *imageView = self.subviews[index];
        return imageView.image;
}
- (NSURL *)photoBrowser:(LBrowsePhotoView *)browser highQualityImageURLForIndex:(NSInteger)index
{
    
    NSString *imageName = [NSString stringWithFormat:@"%@",self.picPathStringsArray[index]];
    NSURL *url = [[NSBundle mainBundle] URLForResource:imageName withExtension:nil];
    return url;
}


-(void)setPicPathStringsArray:(NSArray *)picPathStringsArray
{
    _picPathStringsArray=picPathStringsArray;
    
    for (long i = picPathStringsArray.count; i<self.imageViewsArray.count; i++) {
        UIImageView *imageView = [self.imageViewsArray objectAtIndex:i];
        imageView.hidden = YES;
        
        
        
        
    }
    
    
    
    CGFloat itemW = [self itemWidthForPicPathArray:_picPathStringsArray];
    CGFloat itemH = 0;
    if (_picPathStringsArray.count == 1) {

        itemH = ScreenWidth-70;

    } else {
        itemH = itemW;
    }
    
    
    
    
    long perRowItemCount = [self perRowItemCountForPicPathArray:_picPathStringsArray];
    CGFloat margin = 10;
    
    [_picPathStringsArray enumerateObjectsUsingBlock:^(NSString *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        long columnIndex = idx % perRowItemCount;
        long rowIndex = idx / perRowItemCount;
        UIImageView *imageView = [_imageViewsArray objectAtIndex:idx];
        
        imageView.hidden = NO;
        NSString*str=@"http://zk-finance2-http-dev.ipaas.zhonglele.com/";
        NSString *imgStr=[NSString stringWithFormat:@"%@%@",str,obj];
        
        [imageView sd_setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed:@"1.jpg"]];
    
        imageView.frame = CGRectMake(columnIndex * (itemW + margin), rowIndex * (itemH + margin), itemW, itemH);
      
    }];
 
}
- (CGFloat)itemWidthForPicPathArray:(NSArray *)array
{
    if (array.count == 1) {
        return ScreenWidth-70;
    } else {
        CGFloat w = (ScreenWidth-90)/3;
        return w;
    }
}

- (NSInteger)perRowItemCountForPicPathArray:(NSArray *)array
{
    if (array.count < 3) {
        return array.count;
    }  else {
        return 3;
    }
}




@end

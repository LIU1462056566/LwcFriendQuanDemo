//
//  LCicleFriendsTableViewCell.m
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/15.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LCicleFriendsTableViewCell.h"
#import "LimagesViewPresentModel.h"
@implementation LCicleFriendsTableViewCell
{
    NSMutableArray *picArray;
}
-(void)setDataModel:(LCircleFriendsModel *)dataModel
{
    _dataModel=dataModel;
    
    _lwc_distent.text=dataModel.distance;
    _lwc_title.text=dataModel.shopName;
    if ([dataModel.shopImage hasPrefix:@"http"]) {
         [_lwc_headImageView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",dataModel.shopImage]] placeholderImage:[UIImage imageNamed:@"1.jpg"]];
    }else{
     
        NSString *imgStr=dataModel.shopImage;
        NSString *strUrl = [[NSString stringWithFormat:@"http://zk-finance2-http-dev.ipaas.zhonglele.com/%@",imgStr] stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
        
      
         [_lwc_headImageView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",strUrl]] placeholderImage:[UIImage imageNamed:@"1.jpg"]];
    }
   
    _lwc_time.text=dataModel.timeAgo;
    _lwc_content.text=dataModel.dynamicContents;
    _lwc_zanNumber.text=[NSString stringWithFormat:@"%@",dataModel.upvoteQuantity];
    
    

    
    NSMutableArray *picNumberArr=[[NSMutableArray alloc]init];
  
    for (LimagesViewPresentModel *ImageModel in dataModel.pics) {
        [picNumberArr addObject:ImageModel.picName];
    }
    
   
    
    if (picNumberArr.count==0) {
        [_lwc_bgView mas_updateConstraints:^(MASConstraintMaker *make) {
                                make.height.offset(0);
          }];
        dataModel.ImageHeight=@"0";
        
    }else if (picNumberArr.count==1){
        CGFloat itemH;

        itemH=ScreenWidth-70;
        
        

        [_lwc_bgView mas_updateConstraints:^(MASConstraintMaker *make) {
                                make.height.offset(itemH);
           }];
        dataModel.ImageHeight=[NSString stringWithFormat:@"%f",itemH];
        
    }else if(picNumberArr.count<4){
        [_lwc_bgView mas_updateConstraints:^(MASConstraintMaker *make) {
                                make.height.offset((ScreenWidth-90)/3);
                            }];
        
        dataModel.ImageHeight=[NSString stringWithFormat:@"%f",(ScreenWidth-90)/3];
    }else if(picNumberArr.count<7){
        [_lwc_bgView mas_updateConstraints:^(MASConstraintMaker *make) {
                                make.height.offset((ScreenWidth-90)*2/3+10);
                            }];
         dataModel.ImageHeight=[NSString stringWithFormat:@"%f",(ScreenWidth-90)*2/3+10];
    }else{
        [_lwc_bgView mas_updateConstraints:^(MASConstraintMaker *make) {
                                make.height.offset((ScreenWidth-90)+20);
                            }];
         dataModel.ImageHeight=[NSString stringWithFormat:@"%f",(ScreenWidth-90)+20];
    }
    
    
     _lwc_bgView.picPathStringsArray=picNumberArr;
    
   
}



-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setUI];
    }return self;
}
-(void)setUI{
    [self addSubview:self.lwc_headImageView];
    [self addSubview:self.lwc_title];
    [self addSubview:self.lwc_time];
    [self addSubview:self.lwc_content];
    [self addSubview:self.lwc_bgView];
    [self addSubview:self.lwc_distent];
    [self addSubview:self.lwc_zanImageView];
    [self addSubview:self.lwc_zanNumber];
    
    
    
    
    [_lwc_headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.top.offset(10);
        make.width.height.offset(30);
        
        
    }];
    
    [_lwc_title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_lwc_headImageView.mas_right).offset(10);
        make.centerY.equalTo(_lwc_headImageView.mas_centerY);
        make.right.offset(-45);
    }];
    
    
    [_lwc_time mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-10);
        make.centerY.equalTo(_lwc_title.mas_centerY);
        make.width.offset(50);
    }];
    
    
    [_lwc_content mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_lwc_headImageView.mas_left);
        make.top.equalTo(_lwc_headImageView.mas_bottom).offset(10);
        make.right.offset(-45);
    }];
    
    
    [_lwc_bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.right.offset(-45);
        make.top.equalTo(_lwc_content.mas_bottom).offset(10);
    }];
    
    
    
    
    
    [_lwc_distent mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(15);
        make.bottom.offset(-10);
    }];
    
    [_lwc_zanNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-10);
        make.bottom.offset(-10);
    
    }];
    
    
    [_lwc_zanImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_lwc_zanNumber.mas_left).offset(-10);
        make.centerY.equalTo(_lwc_zanNumber.mas_centerY);
        make.width.height.offset(20);
    }];
    
   
    
    
}

-(UIImageView *)lwc_headImageView
{
    if (!_lwc_headImageView) {
        _lwc_headImageView=[[UIImageView alloc]init];
        _lwc_headImageView.image=[UIImage imageNamed:@"1.jpg"];
    }return _lwc_headImageView;
}

-(UILabel *)lwc_title
{
    if (!_lwc_title) {
        _lwc_title=[UILabel new];
//        _lwc_title.font=[UIFont systemFontOfSize:(lwcisIphone5s) ? 12 : 14];
        _lwc_title.font=[UIFont systemFontOfSize:14];
        _lwc_title.textColor=[UIColor darkGrayColor];
        _lwc_title.text=@"南昌赣沪投资管理有限公司";
    }return _lwc_title;
}
-(UILabel *)lwc_time
{
    if (!_lwc_time) {
        _lwc_time=[UILabel new];
        //   _lwc_title.font=[UIFont systemFontOfSize:(lwcisIphone5s) ? 12 : 14];
        _lwc_time.font=[UIFont systemFontOfSize:12];
        _lwc_time.textColor=[UIColor lightGrayColor];
        _lwc_time.text=@"14:23";
    }return _lwc_time;
}
-(UILabel *)lwc_content
{
    if (!_lwc_content) {
        _lwc_content=[UILabel new];
        //        _lwc_title.font=[UIFont systemFontOfSize:(lwcisIphone5s) ? 12 : 14];
        _lwc_content.font=[UIFont systemFontOfSize:16];
        _lwc_content.text=@"开门营业，欢迎广大客户前来咨询服务";
        _lwc_content.numberOfLines=0;
    }return _lwc_content;
}

-(LPicContentView *)lwc_bgView
{
    if (!_lwc_bgView) {
        _lwc_bgView=[[LPicContentView alloc]init];
//        _lwc_bgView.userInteractionEnabled=YES;
//        _lwc_bgView.contentMode=UIViewContentModeScaleAspectFit;
        _lwc_bgView.clipsToBounds=YES;
    }return _lwc_bgView;
}
-(UILabel *)lwc_distent
{
    if (!_lwc_distent) {
        _lwc_distent=[UILabel new];
        //        _lwc_title.font=[UIFont systemFontOfSize:(lwcisIphone5s) ? 12 : 14];
        _lwc_distent.font=[UIFont systemFontOfSize:12];
        _lwc_distent.textColor=[UIColor lightGrayColor];
        _lwc_distent.text=@"2.6Km";
    }return _lwc_distent;
}
-(UILabel *)lwc_zanNumber
{
    if (!_lwc_zanNumber) {
        _lwc_zanNumber=[UILabel new];
        //        _lwc_title.font=[UIFont systemFontOfSize:(lwcisIphone5s) ? 12 : 14];
        _lwc_zanNumber.font=[UIFont systemFontOfSize:12];
        _lwc_zanNumber.textColor=[UIColor lightGrayColor];
        _lwc_zanNumber.text=@"(10)";
    }return _lwc_zanNumber;
}
-(UIImageView *)lwc_zanImageView
{
    if (!_lwc_zanImageView) {
        _lwc_zanImageView=[[UIImageView alloc]init];
        _lwc_zanImageView.image=[UIImage imageNamed:@"心"];
    }return _lwc_zanImageView;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

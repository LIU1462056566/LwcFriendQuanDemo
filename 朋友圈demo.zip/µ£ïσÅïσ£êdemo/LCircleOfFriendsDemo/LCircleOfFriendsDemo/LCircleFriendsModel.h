//
//  LCircleFriendsModel.h
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/15.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LCircleFriendsModel : NSObject

//** <#注释#> **//
@property(nonatomic,copy)NSString * distance   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * dynamicContents   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * hasUpvoted   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * ID   ;
//** <#注释#> **//
@property(nonatomic,copy)NSMutableArray * pics   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * publishTime   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * sellerUserId   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * shopImage   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * shopName   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * timeAgo   ;
//** <#注释#> **//
@property(nonatomic,copy)NSString * upvoteQuantity   ;


//** ImageHeight **//
@property(nonatomic,copy)NSString * ImageHeight   ;

@end

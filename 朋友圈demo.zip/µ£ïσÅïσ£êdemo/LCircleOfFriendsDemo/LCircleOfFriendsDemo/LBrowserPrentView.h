//
//  LBrowserPrentView.h
//  LCircleOfFriendsDemo
//
//  Created by 张晴顺 on 2017/6/16.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LWaittingProgressView.h"
@interface LBrowserPrentView : UIImageView<UIGestureRecognizerDelegate>


@property(nonatomic,assign,readonly)BOOL isScaled;
@property(nonatomic,assign)CGFloat lwc_progress;//进度条
@property (nonatomic, assign) BOOL hasLoadedImage;

-(void)doubleTapToZoomWithScale:(CGFloat)scale;
- (void)eliminateScale;// 清除缩放
- (void)clear;
@end
